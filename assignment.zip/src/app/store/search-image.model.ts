export interface SearchImage {
    list: []
  }
  